# Malware Embedder

This project consists of two Python scripts: `embedder.py` and `payload.py`.

## `embedder.py`

This script is used to embed a Python payload into an image file.

### Usage

1.  **Prepare your payload:** Create a Python script that will act as your malware. Save it as `payload.py`.
2.  **Choose an image:** Select an image file (e.g., `.jpg`, `.png`) that you want to use as the carrier.
3.  **Run the embedder:** Execute the `embedder.py` script with the image file and the payload file as arguments.

        python embedder.py <image_file_path> <output_image_path>
    
    *   `<image_file_path>`: The path to the original image file.
    *   `<output_image_path>`: The path where the modified image with the embedded payload will be saved.

The script will read the content of `payload.py` and append it to the end of the image file. The resulting image file will appear to be a normal image but will contain the executable Python code.

## `payload.py`

This script contains the actual malware code that will be embedded. For demonstration purposes, this example `payload.py` will simply print a message indicating it has been executed.

**Note:** In a real-world scenario, `payload.py` would contain malicious code.

## How to Execute the Embedded Payload

To execute the embedded payload, you need to:

1.  **Extract the payload:** The payload is appended to the end of the image file. You can extract it by reading the image file from a specific point (where the original image data ends) to the end of the file.
2.  **Execute the extracted payload:** Once extracted, the payload can be executed as a Python script.

**Example of extraction and execution (conceptual):**

You would typically write a separate script or modify `embedder.py` to include an extraction mechanism. A simple way to extract is to find the end of the legitimate image data and then read the rest.

For example, if you know the size of the original image, you can slice the file. Or, a more robust method involves checking image headers.

Once extracted, save the content to a new `.py` file and run it:

python extracted_payload.py

**Disclaimer:** This project is for educational and research purposes only. Creating and distributing malware is illegal and unethical. Use this information responsibly and only in controlled environments for security testing.